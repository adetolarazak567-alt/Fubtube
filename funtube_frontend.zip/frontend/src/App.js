
import React from 'react'
import Navbar from './components/Navbar'
import ReelsFeed from './components/ReelsFeed'
import ToolsPage from './components/ToolsPage'

export default function App(){
  // Simple client-side routing via hash
  const page = window.location.hash.replace('#','') || 'home'
  return (
    <div>
      <Navbar />
      {page === 'tools' ? <ToolsPage /> : <ReelsFeed />}
    </div>
  )
}
