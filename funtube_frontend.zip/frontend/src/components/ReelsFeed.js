
import React, { useEffect, useState, useRef } from 'react'

const API = (import.meta.env.VITE_API_BASE || 'http://localhost:5000') + '/api'

export default function ReelsFeed(){
  const [reels, setReels] = useState([])
  const [page, setPage] = useState(0)

  useEffect(()=>{ fetchReels() },[])

  async function fetchReels(){
    try{
      const res = await fetch(API + '/reels')
      const data = await res.json()
      setReels(data)
    }catch(e){ console.warn(e) }
  }

  return (
    <div className="feed">
      {reels.map(r => <ReelCard key={r.id} reel={r} />)}
    </div>
  )
}

function ReelCard({ reel }){
  const vref = useRef(null)
  const [liked, setLiked] = useState(false)
  const [comments, setComments] = useState([])
  const [commentText, setCommentText] = useState('')

  useEffect(()=>{
    const v = vref.current
    if(!v) return
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => { if(e.isIntersecting) v.play(); else v.pause() })
    }, { threshold: 0.6 })
    obs.observe(v)
    return () => obs.disconnect()
  },[])

  async function toggleLike(){
    setLiked(!liked)
    // send to backend
    try{ await fetch('/api/likes', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({videoId:reel.id, liked: !liked})}) }catch(e){}
  }

  async function postComment(){
    if(!commentText) return
    setComments(prev=>[...prev,{text:commentText, id:Date.now()}])
    setCommentText('')
    try{ await fetch('/api/comments', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({videoId:reel.id, text: commentText})})}catch(e){}
  }

  function share(){
    if(navigator.share){ navigator.share({title: reel.title, url: reel.url}).catch(()=>{}) }
    else { navigator.clipboard.writeText(window.location.href + '#video=' + reel.id) }
  }

  return (
    <div className="card">
      <div className="videoWrap">
        <video ref={vref} src={reel.url} playsInline muted loop style={{width:'100%',height:'100%',objectFit:'cover'}} />
        <div className="actions">
          <div className="actionBtn" onClick={toggleLike}>{liked? '♥':'♡'}</div>
          <div className="actionBtn" onClick={()=>{ document.getElementById('comments-'+reel.id).style.display='block' }}>💬</div>
          <div className="actionBtn" onClick={share}>⤴</div>
        </div>
      </div>
      <div className="title">{reel.title}</div>
      <div className="controls">
        <div className="small">{reel.description}</div>
        <div className="small">Views: {reel.views || 0}</div>
      </div>
      <div id={'comments-'+reel.id} style={{display:'none',padding:8}}>
        <div>
          {comments.map(c=> <div key={c.id} style={{padding:'6px 0'}}>{c.text}</div>)}
        </div>
        <div style={{display:'flex',gap:8,marginTop:8}}>
          <input value={commentText} onChange={e=>setCommentText(e.target.value)} placeholder="Add comment" style={{flex:1,padding:8,borderRadius:6,border:'none'}}/>
          <button onClick={postComment} style={{padding:'8px 12px',borderRadius:6}}>Post</button>
        </div>
      </div>
    </div>
  )
}
