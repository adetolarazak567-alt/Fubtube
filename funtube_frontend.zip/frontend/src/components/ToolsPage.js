
import React from 'react'
const links = [
  {name:'Honeygain', url:'https://join.honeygain.com/ADETO9812A', desc:'Earn passive income by sharing bandwidth.'},
  {name:'JumpTask', url:'https://www.jumptask.io/r/rimyxydyrime', desc:'Complete microtasks for money.'},
  {name:'Swagbucks', url:'https://www.swagbucks.com/p/register?rb=202554742&rp=1', desc:'Surveys, offers, and rewards.'},
  {name:'TimeBucks', url:'https://timebucks.com/?refID=226633453', desc:'Multiple ways to earn online.'},
  {name:'PacketStream', url:'https://packetstream.io/?psr=7Lek', desc:'Resell unused bandwidth.'},
  {name:'FreeCash', url:'https://freecash.com/r/MEJVV', desc:'Surveys, offers, and games.'},
  {name:'ySense', url:'https://www.ysense.com/?rb=217956526', desc:'Surveys and tasks.'}
]

export default function ToolsPage(){
  return (
    <div className="feed" style={{paddingTop:12}}>
      <div style={{maxWidth:480,margin:'0 auto'}}>
        <h2 style={{marginBottom:12}}>Earning Tools</h2>
        {links.map(l=> (
          <div key={l.name} style={{background:'rgba(255,255,255,0.03)',padding:12,borderRadius:8,marginBottom:10}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <div>
                <div style={{fontWeight:700}}>{l.name}</div>
                <div style={{fontSize:13,opacity:0.8}}>{l.desc}</div>
              </div>
              <div>
                <a href={l.url} target="_blank" rel="noreferrer" style={{background:'#06b6d4',padding:'8px 10px',borderRadius:6,color:'#042',textDecoration:'none',fontWeight:700}}>Join Now</a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
