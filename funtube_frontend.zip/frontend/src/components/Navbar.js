
import React from 'react'
export default function Navbar(){
  return (
    <div className="header">
      <div style={{display:'flex',gap:12,alignItems:'center'}}>
        <div className="logo">FTube</div>
        <div className="small">FunTube - Watch Reels, Earn & Explore</div>
      </div>
      <div style={{display:'flex',gap:8}}>
        <a href="#home" style={{color:'#fff',textDecoration:'none'}}>Home</a>
        <a href="#tools" style={{color:'#fff',textDecoration:'none'}}>Earning Tools</a>
      </div>
    </div>
  )
}
