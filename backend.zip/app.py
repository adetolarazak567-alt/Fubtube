from flask import Flask, jsonify
from config import Config
from routes import bp, init_db

app = Flask(__name__)
app.config.from_object(Config)

# Register API blueprint
app.register_blueprint(bp, url_prefix="/api")

# Initialize DB (safe to call on start)
init_db()

@app.route("/")
def home():
    return jsonify({"message":"FunTube backend running"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(__import__('os').env.get('PORT', 5000)))